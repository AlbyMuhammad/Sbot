// menu fitur bot
const help = (prefix, instagram, yt, name, pushname2, user, limitt, uptime, jam, tanggal, corohelp) => { 
	return `
	
*🔰⚜️ ${name} ⚜️️️🔰*
*🔅NAMA:* ${pushname2}
*🔅JAM:* ${jam} *WIB*
*🔅KALENDER:* ${tanggal}
*🔅PENGGUNA:* ${user.length} *PENGGUNA*

*🔰⚜️ COVID ID ⚜️️️🔰*
*♨️ POSITIF:* ${corohelp.confirmed.value}
*♨️ SEMBUH:* ${corohelp.recovered.value}
*♨️ MENINGGAL:* ${corohelp.deaths.value}
*♨️ LAST UPDATE:* ${corohelp.lastUpdate}

_⚠️TETAP JAGA KESEHATAN, DAN GUNAKAN MASKER⚠️_

*🔰⚜️ MENU1 ⚜️️️🔰*
*♻️ ${prefix}info*
*♻️ ${prefix}owner
*♻️ ${prefix}donasi*
*♻️ ${prefix}speed*
*♻️ ${prefix}verify*
*♻️ ${prefix}limit*
*♻️ ${prefix}blocklist*
*♻️ ${prefix}banlist*
*♻️ ${prefix}totaluser*
*🔰⚜️ MENU1 ⚜️️️🔰*

*🔰⚜️ MENU2 ⚜️️️🔰*
🌐 *${prefix}tiktokstalk (username)*
🌐 *${prefix}igstalk (username)*
🌐 *${prefix}instavid (link)*
🌐 *${prefix}instaimg (link)*
🌐 *${prefix}instastory (username)*
🌐 *${prefix}ssweb (url)*
🌐 *${prefix}url2img(url)*
🌐 *${prefix}tiktok*
🌐 *${prefix}fototiktok*
🌐 *${prefix}kbbi*
🌐 *${prefix}wait*
🌐 *${prefix}trendtwit*
🌐 *${prefix}google berita terkini*
*🔰⚜️ MENU2 ⚜️️️🔰*

*🔰⚜️ MENU3 ⚜️️️🔰*
🌐 *${prefix}quotemaker (text/nama/tema)*
🌐 *${prefix}nulis (nama/kelas/text)*
🌐 *${prefix}croman (text)*
🌐 *${prefix}slide (text)*
🌐 *${prefix}tahta (text)*
🌐 *${prefix}cglass (text)*
🌐 *${prefix}cstyle (text)*
🌐 *${prefix}cgame (text)*
🌐 *${prefix}clove (text)*
🌐 *${prefix}cparty (text)*
🌐 *${prefix}csky (text)*
🌐 *${prefix}tts id (text)*
🌐 *${prefix}ttp (text)*
🌐 *${prefix}cpaper (text)*
🌐 *${prefix}stiker*
🌐 *${prefix}gifstiker*
🌐 *${prefix}toimg*
🌐 *${prefix}img2url*
🌐 *${prefix}tomp3*
🌐 *${prefix}ocr*
*🔰⚜️ MENU3 ⚜️️️🔰*

*🔰⚜️ MENU4 ⚜️️️🔰*
🌐 *${prefix}modeanime (mode)*
🌐 *${prefix}neonime naruto*
🌐 *${prefix}naruto*
🌐 *${prefix}minato*
🌐 *${prefix}boruto*
🌐 *${prefix}hinata*
🌐 *${prefix}sakura*
🌐 *${prefix}sasuke*
🌐 *${prefix}toukachan*
🌐 *${prefix}rize*
🌐 *${prefix}akira*
🌐 *${prefix}itori*
🌐 *${prefix}kurumi*
🌐 *${prefix}miku*
🌐 *${prefix}anime*
🌐 *${prefix}animecry*
🌐 *${prefix}animekiss*
*🔰⚜️ MENU4 ⚜️️️🔰*

*🔰⚜️ MENU5 ⚜️️️🔰*
🌐 *${prefix}welcome (mode)*
🌐 *${prefix}grup (mode)*
🌐 *${prefix}ownergrup*
🌐 *${prefix}setpp*
🌐 *${prefix}infogc*
🌐 *${prefix}add 628xxxxxxxxxx*
🌐 *${prefix}kick @tag*
🌐 *${prefix}kicktime @tag*
🌐 *${prefix}promote @tag*
🌐 *${prefix}demote @tag*
🌐 *${prefix}setname*
🌐 *${prefix}setdesc*
🌐 *${prefix}linkgrup*
🌐 *${prefix}tagme*
🌐 *${prefix}hidetag*
🌐 *${prefix}tagall*
🌐 *${prefix}mentionall*
🌐 *${prefix}fitnah @tag/isi/balasan*
🌐 *${prefix}listadmin*
*🔰⚜️ MENU5 ⚜️️️🔰*

*🔰⚜️ MENU6 ⚜️️️🔰*
🌐 *${prefix}nsfw (mode)*
🌐 *${prefix}nsfwloli*
🌐 *${prefix}nsfwblowjob*
🌐 *${prefix}nsfwneko*
🌐 *${prefix}nsfwtrap*
🌐 *${prefix}hentai*
🌐 *${prefix}simih (mode)*
🌐 *${prefix}public (mode)
🌐 *${prefix}anjing*
🌐 *${prefix}kucing*
🌐 *${prefix}testime*
🌐 *${prefix}hilih*
🌐 *${prefix}apakah*
🌐 *${prefix}kapankah*
🌐 *${prefix}bisakah*
🌐 *${prefix}rate*
🌐 *${prefix}watak*
🌐 *${prefix}hobby*
🌐 *${prefix}infogempa*
🌐 *${prefix}infonomor*
🌐 *${prefix}quotes*
🌐 *${prefix}truth*
🌐 *${prefix}dare*
🌐 *${prefix}katabijak*
🌐 *${prefix}fakta*
🌐 *${prefix}darkjokes*
🌐 *${prefix}bucin*
🌐 *${prefix}pantun*
🌐 *${prefix}katacinta*
🌐 *${prefix}jadwaltvnow*
🌐 *${prefix}hekerbucin*
🌐 *${prefix}katailham*
*⚜️ MENU6 ⚜️️️🔰*

*⚜️ MENU7 ⚜️️️🔰*
🌐 *${prefix}jarak Jakarta/Bogor*
🌐 *${prefix}translate en/Halo Kawan*
🌐 *${prefix}pasangan Satria/Lina*
🌐 *${prefix}gantengcek Satria*
🌐 *${prefix}cantikcek Lina*
🌐 *${prefix}artinama Satria*
🌐 *${prefix}persengay Satria*
🌐 *${prefix}pbucin Satria*
🌐 *${prefix}bpfont (text)*
🌐 *${prefix}textstyle (text)*
🌐 *${prefix}jadwaltv (channel)*
🌐 *${prefix}lirik (nama lagu)*
🌐 *${prefix}chord (nama lagu)*
🌐 *${prefix}wiki (search)*
🌐 *${prefix}brainly (pertanyaan)*
🌐 *${prefix}resepmasakan (nama makanan)*
🌐 *${prefix}map (lokasi)*
🌐 *${prefix}covid (negara)*
🌐 *${prefix}film (nama film)*
🌐 *${prefix}pinterest (search foto)*
🌐 *${prefix}infocuaca (lokasi)*
🌐 *${prefix}jamdunia (lokasi)*
🌐 *${prefix}mimpi (text)*
🌐 *${prefix}infoalamat jalan (lokasi)*
🌐 *${prefix}playstore (nama apk)*
*⚜️ MENU7 ⚜️️️🔰*

*⚜️ MENU8 ⚜️️️🔰*
🌐 *${prefix}readmore (text)*
🌐 *${prefix}puisiimg*
🌐 *${prefix}asupan*
🌐 *${prefix}tebakgambar*
🌐 *${prefix}caklontong*
🌐 *${prefix}family100*
🌐 *${prefix}memeindo*
🌐 *${prefix}kalkulator (angka)*
🌐 *${prefix}moddroid (nama apk)*
🌐 *${prefix}happymod (nama apk)*
🌐 *${prefix}randomKPOP*
🌐 *${prefix}cersex*
🌐 *${prefix}randombokep*
🌐 *${prefix}pornhub (search pornhub)*
🌐 *${prefix}xvideos (negara)*
🌐 *${prefix}nekopoi (judul)*
🌐 *${prefix}jadwalsholat (lokasi)*
🌐 *${prefix}quran*
🌐 *${prefix}quranlist*
🌐 *${prefix}quransurah (angka)*
*⚜️ MENU8 ⚜️️️🔰*

*⚜️ MENU9 ⚜️️️🔰*
🌐 *${prefix}becrypt string*
🌐 *${prefix}encode64 string*
🌐 *${prefix}decode64 encrypt*
🌐 *${prefix}encode32 string*
🌐 *${prefix}decode32 encrypt*
🌐 *${prefix}encbinary string*
🌐 *${prefix}decbinary encrypt*
🌐 *${prefix}encoctal string*
🌐 *${prefix}decoctal encrypt*
🌐 *${prefix}hashidentifier Encrypt Hash*
🌐 *${prefix}dorking dork*
🌐 *${prefix}pastebin (text)*
🌐 *${prefix}tinyurl (link)*
🌐 *${prefix}bitly (link)*
🌐 *${prefix}spamcall 083xxxxxxxxx*
🌐 *${prefix}spamgmail contoh@gmail.com*
*⚜️ MENU9 ⚜️️️🔰*

*⚜️ MENU10 ⚜️️️🔰*
🌐 *${prefix}addprem (@tag)*
🌐 *${prefix}removeprem (@tag)*
🌐 *${prefix}setmemlimit*
🌐 *${prefix}setlimit*
🌐 *${prefix}setreply*
🌐 *${prefix}setprefix*
🌐 *${prefix}setnamebot*
🌐 *${prefix}setppbot*
🌐 *${prefix}bc*
🌐 *${prefix}bcgc*
🌐 *${prefix}ban*
🌐 *${prefix}unban*
🌐 *${prefix}block*
🌐 *${prefix}unblock*
🌐 *${prefix}clearall*
🌐 *${prefix}delete*
🌐 *${prefix}clone*
🌐 *${prefix}getses*
🌐 *${prefix}leave*
*⚜️ MENU10 ⚜️️️🔰*

*⚜️ MENU11 ⚜️️️🔰*
🌐 *${prefix}playmp3 menepi*
🌐 *${prefix}fb link video*
🌐 *${prefix}snack link snack video*
🌐 *${prefix}ytmp3 link yt*
🌐 *${prefix}ytmp4 link yt*
🌐 *${prefix}joox Monolog Pamungkas*
🌐 *${prefix}smule Link Video Smule*
*⚜️ MENU11 ⚜️️️🔰*

*⚜️ THANKS TO ⚜️️️🔰*
♻️ *ALLAH*
♻️ *M. HADI FIRMANSYA*
♻️ *DELIA AULIA*
♻️ *KEVIN DAVID*
♻️ *FARHAN GANS*
*⚜️ THANKS TO ⚜️️️🔰*
}

exports.help = help

// penghitung aktif bot
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}

// info bot 
const bottt = (prefix) => {
return `
*[ ❗ ] AKTIFKAN BOT ${prefix}bott aktif*
`
}
exports.bottt = bottt
// donasi menu
const donasi = (name) => { 
	return `       
*⚜️ DONASI ⚜️️️🔰*
♻️ Smartfreen: 088290272656
♻️ Three: 0895327281175
♻️ Chat: wa.me/62895327281175
*⚜️ DONASI ⚜️️️🔰*

`
}
exports.donasi = donasi

// bahasa list
const bahasa = (prefix) => {
return `
*⚜️ BAHASA NEGARA ⚜️️️🔰*
🌐af: Afrikaans
🌐sq: Albanian
🌐ar: Arabic
🌐hy: Armenian
🌐ca: Catalan
🌐zh: Chinese
🌐zh-cn: Chinese (Mandarin/China)
🌐zh-tw: Chinese (Mandarin/Taiwan)
🌐zh-yue: Chinese (Cantonese)
🌐hr: Croatian
🌐cs: Czech
🌐da: Danish
🌐nl: Dutch
🌐en: English
🌐en-au: English (Australia)
🌐en-uk: English (United Kingdom)
🌐en-us: English (United States)
🌐eo: Esperanto
🌐fi: Finnish
🌐fr: French
🌐de: German
🌐el: Greek
🌐ht: Haitian Creole
🌐hi: Hindi
🌐hu: Hungarian
🌐is: Icelandic
🌐id: Indonesian
🌐it: Italian
🌐ja: Japanese
🌐ko: Korean
🌐la: Latin
🌐lv: Latvian
🌐mk: Macedonian
🌐no: Norwegian
🌐pl: Polish
🌐pt: Portuguese
🌐pt-br: Portuguese (Brazil)
🌐ro: Romanian
🌐ru: Russian
🌐sr: Serbian
🌐sk: Slovak
🌐es: Spanish
🌐es-es: Spanish (Spain)
🌐es-us: Spanish (United States)
🌐sw: Swahili
🌐sv: Swedish
🌐ta: Tamil
🌐th: Thai
🌐tr: Turkish
🌐vi: Vietnamese
🌐cy: Welsh
*⚜️ BAHASA NEGARA ⚜️️️🔰*
`
}
exports.bahasa = bahasa

// Limit
const limitend = (pushname2) => {
        return`*[ ❗ ] LIMIT ANDA HABIS!!*`
}

const limitcount = (limitCounts) => {
        return`
*💳 Limit Kamu:* ${limitCounts}
`
}

exports.limitend = limitend
exports.limitcount = limitcount